# Dr. Aparanta Debnath — Online Appointment System (V1)

This is a standalone browser prototype.

Features:
- Date selection
- 25 New Patient tickets (1–25)
- 5 Report/Follow-up tickets (R1–R5)
- 12:00 PM–3:00 PM schedule
- ₹400 consultation fee display
- Patient details form
- Booking confirmation/ticket
- Browser-local Admin appointment list
- CSV export
- Responsive mobile design

Important:
- This V1 does NOT process real payments.
- Data is stored in the browser's localStorage, so it is not yet a multi-device/cloud system.
- For production use, add a secure backend/database, real UPI/payment gateway, SMS/WhatsApp confirmation, authentication, HTTPS, privacy policy and data protection.
